nix-env -i /nix/store/f55bnm8q1giaxpb8rw615l0zflcx8n6x-firefox-78.13.0esr
firefox

